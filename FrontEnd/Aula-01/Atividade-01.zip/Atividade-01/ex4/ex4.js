var temperatura = Number(prompt("Digite a temperatura"))

alert((temperatura - 32) * (0.5556));
