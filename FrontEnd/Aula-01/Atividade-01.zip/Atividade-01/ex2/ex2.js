
var numero1 = Number(prompt("Digite o numero1"))

var numero2 = Number(prompt("Digite o numero2"))

alert(numero1 + numero2);

var numero3 = Number(prompt("Digite o numero3"))

var numero4 = Number(prompt("Digite o numero4"))

alert(numero3 - numero4);

var numero5 = Number(prompt("Digite o numero5"))

var numero6 = Number(prompt("Digite o numero6"))

alert(numero5 * numero6);

var numero7 = Number(prompt("Digite o numero7"))

var numero8 = Number(prompt("Digite o numero8"))

alert(numero7 / numero8);

