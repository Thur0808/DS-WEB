var nome = prompt("Digite o seu nome")
var sobrenome = prompt("Digite o seu sobrenome")
console.log(nome + " " +  sobrenome)
alert(nome + " " +  sobrenome)