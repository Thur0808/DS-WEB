var numero = Number(prompt("Digite o valor"))

alert(numero * numero * numero);
